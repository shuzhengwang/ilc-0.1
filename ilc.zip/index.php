<?php 
include("db.php");
include("includes/header.php"); ?>
  
  <!-- start of hero -->
  <section class="hero hero-slider-wrapper">
    <div class="hero-slider">
      <div class="slide"> <img src="images/slider/adventure_banner.jpg" alt>
        <div style="top:30%" class="title"> <span >International Library Of Cannabinoids</span>
          <h3 style="margin-top:4%">Medical Database</h3>
         <input style="width:50%;margin-left:30%;margin-top:15%" id="form_name" type="text" name="name" class="form-control" placeholder="Search" required="required" data-error="Name is required."></div>
      </div>
      <div class="slide"> <img src="images/slider/adventure_banner.jpg" alt>
        <div style="top:30%" class="title"> <span >International Library Of Cannabinoids</span>
          <h3 style="margin-top:4%">Medical Database</h3>
         <input style="width:50%;margin-left:30%;margin-top:15%" id="form_name" type="text" name="name" class="form-control" placeholder="Search" required="required" data-error="Name is required."></div> </div>
      </div>
      
    </div>
  </section>
  <!-- end hero slider --> 
  

  

  
  <!--Blog Section-->
  <section class="blog">
    <div style="padding-top: 0px;padding-bottom: 0px;" class="container">
      
      <div class="section-content">
        <div class="row">
          
          <div class="col-sm-6 col-md-4 wow slideInLeft" data-wow-duration="1s" data-wow-delay=".5s">
            
          </div>
        </div>
      </div>
    </div>
  </section>
  <?php include("includes/footer.php"); ?>
  